package com.js.plataformasalud.plataformasalud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlataformasaludApplicationTests {

	@Test
	void contextLoads() {
	}

}
