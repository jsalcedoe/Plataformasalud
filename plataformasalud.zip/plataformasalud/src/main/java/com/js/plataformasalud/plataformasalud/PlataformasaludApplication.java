package com.js.plataformasalud.plataformasalud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlataformasaludApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlataformasaludApplication.class, args);
	}

}
